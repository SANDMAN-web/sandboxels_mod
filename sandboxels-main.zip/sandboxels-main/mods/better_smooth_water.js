elements.water.behavior = [
    "XX|XX|XX",
    "M2%5|XX|M2 AND BO",
    "XX|M1|M2",
];
elements.water.flippableX = true;
runAfterLoad(function(){
    validDensitySwaps.liquid.solid = true
})
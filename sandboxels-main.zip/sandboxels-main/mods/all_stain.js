window.addEventListener('load', function() {
	for (var element in elements) {
		elements[element].stain = 0.1;
	}
});

// sorry alice
Contributions to the main index.html file will be ignored. Use this repository to officially publish your Sandboxels mods.

Rules for publishing mods:
1. Must not focus on something NSFW or illegal.
2. Must be tested beforehand on your own. This repo does not accept mods for the sole purpose of you testing them.
3. Must contain some meaningful content.

Failure to follow these rules may result in your pull request being ignored!

Learn more about [submitting your mod](https://sandboxels.wiki.gg/wiki/Modding_tutorial#Putting_it_online).

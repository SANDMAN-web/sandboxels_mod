# Security Policy

## Supported Versions

The latest version, live on the website, is supported.

## Reporting a Vulnerability

To report a serious security vulnerability, DM a moderator on the R74n / Sandboxels Discord server: https://discord.gg/ejUc6YPQuS
